<body>
  <?php include 'menu.html';?>
  <h1>Sign up</h1>
  <form method="post" action="do_signup.php">
    Enter username <input type="text" name="username" /><br />
    Create password <input type="password" name="password" /> <br />
    <input type="submit" />
  </form>
</body>